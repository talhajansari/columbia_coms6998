//
//  ResultTableViewController.h
//  Hello
//
//  Created by Talha Ansari on 5/9/14.
//  Copyright (c) 2014 Jingwei Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultTableViewController : UITableViewController

@property NSDictionary *res;
@property NSArray *species;
@property NSArray *prob;


@end
