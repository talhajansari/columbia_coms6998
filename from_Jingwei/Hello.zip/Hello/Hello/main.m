//
//  main.m
//  Hello
//
//  Created by Jingwei Zhang on 1/29/14.
//  Copyright (c) 2014 Jingwei Zhang. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
